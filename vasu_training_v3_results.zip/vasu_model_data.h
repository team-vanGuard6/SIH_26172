#pragma once
extern const unsigned char g_vasu_model[];
extern const unsigned int g_vasu_model_len;
