VASU V3 uses speakers 1-3 only. Speakers 4 and 5 remain sealed.
Results are development-selected, not independent accuracy.
Input: 1.2 s / 19200 samples / 59x40x1 log-Mel features.
Do not combine with the old 1-second/49x40 firmware.
Do not open a sealed test set unless development performance is accepted.
Hardware RAM, CPU and latency remain unmeasured until ESP deployment.
