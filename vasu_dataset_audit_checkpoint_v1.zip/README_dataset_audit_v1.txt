VASU DATASET V1 — PRE-TRAINING AUDIT CHECKPOINT

Keyword:
VASU, pronounced Vaa-soo.

Audio format:
16 kHz, mono, signed 16-bit PCM.

Speakers:
Speakers 1–3 are used for training and development.
Speaker 4 remains sealed for the final unseen-speaker test.

Word candidates:
415 manually reviewed word utterances.
Training: 202 Vasu + 94 confusable.
Development: 70 Vasu + 49 confusable.

Negative data:
1,197 one-second negative windows.
Training: 306 other-speech + 95 background.
Development: 559 other-speech + 237 background.

Negative quality audit:
65 windows were sampled across every eligible negative source recording.
Both training and development montages were manually reviewed and clean.

Important:
Some other-speech windows contain partial words because continuous
one-second listening windows naturally cut speech at arbitrary points.
These are valid negative examples.

Development negative windows use a 0.5-second stride and therefore
overlap. They must not be claimed as independent recordings.

No Speaker 4 recording has been used for training, development,
threshold selection, augmentation, or manual model-error analysis.

No model training had started when this checkpoint was created.