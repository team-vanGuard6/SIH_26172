V4 uses speakers 1-3 only. Speakers 4 and 5 remain sealed.
This is development selection, not independent accuracy.
Pipeline: adaptive activity gate -> 1.2 s onset-aligned log-Mel -> 3-class INT8 DS-CNN.
Hardware RAM, CPU and latency remain unmeasured until ESP deployment.
